﻿using Microsoft.SharePoint;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace SPClientLibrary.SpClientLibrary
{
    public partial class SpClientLibraryUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Client_ServerClick(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;

            if (clientName.Value == "")
            {
                lblMessage.Text = "Please enter client Name";
                return;
            }
            string strClientName = clientName.Value.Trim().ToString();
            if (!chkConId.Checked)
            {


                string url = site.RootWeb.Url;



                Guid guid = Guid.Empty;

                foreach (SPWeb web in site.AllWebs)
                {

                    if (web.Name.ToUpper() == strClientName.Substring(0, 1).ToUpper() || web.Url.EndsWith(strClientName.Substring(0, 1)))
                    {
                        guid = web.ID;
                        break;
                    }

                }



                using (SPWeb oSPWeb = site.OpenWeb(guid))
                {

                    oSPWeb.AllowUnsafeUpdates = true;

                    /*create list from custom ListTemplate present within ListTemplateGalery */
                    oSPWeb.Lists.Add(strClientName, stratusCode.Value, SPListTemplateType.DocumentLibrary);

                    oSPWeb.Update();


                    SPList list = oSPWeb.Lists.TryGetList(strClientName);
                    SPListItem folderColl = list.Items.Add(list.RootFolder.ServerRelativeUrl, SPFileSystemObjectType.Folder, "MAIN ACCOUNT");
                    folderColl.Update();
                    list.Update();

                    SPListItem subFolderColl = list.Items.Add(list.RootFolder.ServerRelativeUrl, SPFileSystemObjectType.Folder, "SUB ACCOUNTS");
                    subFolderColl.Update();
                    list.Update();

                    oSPWeb.AllowUnsafeUpdates = false;

                }

            }
            else
            {
                string url = (this.Parent as SpClientLibrary).ConfidentialSiteUrl;
                if (string.IsNullOrEmpty(url))
                {
                    lblMessage.Text = "Please provide the Confidential Site Url";
                    return;
                }
                else
                {

                    using (SPSite oSPsite = new SPSite(url.Trim()))
                    {
                        using (SPWeb oSPWeb = oSPsite.OpenWeb())
                        {

                            oSPWeb.AllowUnsafeUpdates = true;

                            oSPWeb.Lists.Add(strClientName, stratusCode.Value, SPListTemplateType.DocumentLibrary);

                            oSPWeb.Update();


                            SPList list = oSPWeb.Lists.TryGetList(strClientName);
                            SPListItem folderColl = list.Items.Add(list.RootFolder.ServerRelativeUrl, SPFileSystemObjectType.Folder, "MAIN ACCOUNT");
                            folderColl.Update();
                            list.Update();

                            SPListItem subFolderColl = list.Items.Add(list.RootFolder.ServerRelativeUrl, SPFileSystemObjectType.Folder, "SUB ACCOUNTS");
                            subFolderColl.Update();
                            list.Update();

                            oSPWeb.AllowUnsafeUpdates = false;

                        }

                    }
                }
            }


            lblMessage.Text = "Client Folder Created Successfully";
            clientName.Value = "";
            stratusCode.Value = "";
            chkConId.Checked = false;
        }
    }
}
