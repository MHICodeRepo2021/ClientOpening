﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace SPClientLibrary.SpClientLibrary
{
    [ToolboxItemAttribute(false)]
    public class SpClientLibrary : WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/15/SPClientLibrary/SpClientLibrary/SpClientLibraryUserControl.ascx";
        [WebBrowsable(true),
           WebDisplayName("Confidential Site Url"),
           WebDescription("Enter Complete Url"),
           Personalizable(PersonalizationScope.Shared),
           Category("Custom Properties")
       ]
        public string ConfidentialSiteUrl
        {
            get;
            set;
        }

       // [WebBrowsable(true),
       //    WebDisplayName("Main Site Url"),
       //    WebDescription("Create Folder Url ignore or leave empty if library needs to be created in same top level Site collection"),
       //    Personalizable(PersonalizationScope.Shared),
       //    Category("Custom Properties")
       //]
       // public string MainSiteUrl
       // {
       //     get;
       //     set;
       // }

        protected override void CreateChildControls()
        {
            Control control = Page.LoadControl(_ascxPath);
            Controls.Add(control);
        }
    }
}
