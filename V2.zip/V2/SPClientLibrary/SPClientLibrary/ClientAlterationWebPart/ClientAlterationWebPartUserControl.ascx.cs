﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace SPClientLibrary.ClientAlterationWebPart
{
    public partial class ClientAlterationWebPartUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BuildSiteLists();
            }
        }

        protected void ddlLibList_SelectedIndexChanged(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;

            SPWeb web = SPContext.Current.Web;


            ListItem item = this.ddlLibList.SelectedItem;
            SPList spList=null;
            if (item != null)
            {
                foreach (SPList list in (IEnumerable)web.Lists)
                {
                    if (list.Title.Equals(ddlLibList.SelectedItem.Text))
                    {
                        spList = list;
                        break;
                    }
                }
                if(spList!=null)
                    this.ReadCurrentListData(spList);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;
            SPWeb web = SPContext.Current.Web;


            try
            {
                string siteLetter =GetSiteLetter(web.ServerRelativeUrl);

                
               
                SPList spList = (SPList)null;
             

                ListItem item = this.ddlLibList.SelectedItem;
                web.AllowUnsafeUpdates = true;
                if (item != null)
                {
                    
                    
                        foreach (SPList list in (IEnumerable)web.Lists)
                        {
                            if (list.Title.Equals(ddlLibList.SelectedItem.Text))
                            {
                                spList = list;
                                break;
                            }
                        }
                    

                    if (spList == null)
                    {
                        lblMessage.Text = "List not found";
                        return;
                    }


                    spList.Title = this.txtClientNam.Text;
                   // spList.Description = this.txtStaratusCode.Text;
                    spList.Update();

                    string theValue = spList.Title.ToString().Remove(1);
                    if (theValue.ToUpper() != siteLetter.ToUpper())
                    {
                        string str1 = !IsInteger(theValue) ? (!(theValue == "M") ? site.RootWeb.Url + "/" + theValue + "/" : site.RootWeb.Url + "/Mm/")
                                : site.RootWeb.Url + "/Numerical/";
                        try
                        {
                            SPSite spSite = new SPSite(str1);
                            SPWeb spWeb = spSite.OpenWeb();
                            SPListCollection lists = spWeb.Lists;
                            SPListTemplate customListTemplate = spSite.GetCustomListTemplates(spWeb)["Client Directory"];
                            Guid guid = lists.Add(spList.Title.Trim(), spList.Description.ToString(), customListTemplate);
                            SPList list = spWeb.Lists[guid];
                            SPFolder folder1 = spWeb.GetFolder(str1 + spList.Title.Trim());
                            foreach (SPListItem folder2 in (IEnumerable)spList.Folders)
                            {
                                string url = folder2.Url;
                                string str2 = url.Remove(0, url.IndexOf("/"));
                                folder1.SubFolders.Add(str1 + spList.Title.Trim() + str2);
                                folder1.Update();
                            }
                            foreach (SPListItem spListItem in (IEnumerable)spList.Items)
                            {
                                string url = spListItem.File.Url;
                                int length = spList.RootFolder.Url.Length;
                                string str3 = url.Remove(0, url.IndexOf("/"));
                                byte[] numArray = spListItem.File.OpenBinary();
                                folder1.Files.Add(str1 + spList.Title.Trim() + str3, numArray, true);
                                folder1.Update();
                            }
                            spList.Recycle();
                           

                            spWeb?.Dispose();
                            spSite?.Dispose();
                            ((Control)this).Page.Response.Redirect(str1 + spList.Title.ToString());
                        }
                        catch (Exception ex)
                        {
                            lblMessage.Text = (ex.Message.ToString() + str1 + spList.Title);

                        }
                        finally
                        {

                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                ((Control)this).Controls.Clear();
                ((Control)this).Controls.Add((Control)new Literal()
                {
                    Text = (ex.Message + " Client update has failed. Press the back button on your browser and try the process again.")
                });
            }

        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;
            SPWeb web = SPContext.Current.Web;
            try
            {
              
                SPList spList = (SPList)null;

                ListItem item = this.ddlLibList.SelectedItem;
                web.AllowUnsafeUpdates = true;
                if (item != null)
                {
                    foreach (SPList list in (IEnumerable)web.Lists)
                    {
                        if (list.Title.Equals(ddlLibList.SelectedItem.Text))
                        {
                            spList = list;
                            break;
                        }
                    }

                    if (spList != null)
                    {

                        string str1 = spList.Title.ToString();
                        string str2 = !str1.Contains("(Client Closed)") ? str1 + " (Client Closed)" : str1.Replace("(Client Closed)", "");
                        spList.Title = str2;
                        spList.Update();
                        web.AllowUnsafeUpdates = false;
                        lblMessage.Text = "Client Updated Successfully";
                    }
                    else
                    {
                        lblMessage.Text =  " Client update has failed. List not found.";
                    }
                }
            }
            catch (Exception ex)
            {

                lblMessage.Text = (ex.Message + " Client update has failed. Press the back button on your browser and try the process again.");

                
            }

        }

        private void BuildSiteLists()
        {

            SPSite site = SPContext.Current.Site;

            SPWeb web = SPContext.Current.Web;

            try
            {


                foreach (SPList list in (IEnumerable)web.Lists)
                {

                    if (!list.Title.Equals("Master Page Gallery") && list.Title != "Style Library" && list.Title != "Site Pages"
                        && list.Title != "Site Assets")
                    {
                        if(list.BaseTemplate==SPListTemplateType.DocumentLibrary)
                            this.ddlLibList.Items.Add(new ListItem() { Text=list.Title, Value=list.ID.ToString() } );
                    }
                }

                
                
            }
            catch
            {
               
            }
            finally
            {
                
            }
        }

        private void ReadCurrentListData(SPList list)
        {
            try
            {
                this.txtClientNam.Text = list.Title;
               // this.txtStaratusCode.Text = list.Description;
                if (list.Title.Contains("(Client Closed)"))
                {
                    this.btnClose.Text = "Open Client";
                    this.txtClientNam.Font.Bold = true;
                    this.txtClientNam.ReadOnly = true;
                   // this.txtStaratusCode.ReadOnly = true;
                }
                else
                {
                    this.btnClose.Text = "Close Client";
                    this.txtClientNam.Font.Bold = false;
                 //   this.txtStaratusCode.ReadOnly = false;
                    this.txtClientNam.ReadOnly = false;
                }
            }
            catch
            {
                
            }
        }

        private bool IsInteger(string theValue)
        {
            try
            {
                Convert.ToInt32(theValue);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private  string GetSiteLetter(string siteURL)
        {
            string[] rr = siteURL.Split('/');

            int num = rr.Length;
            siteURL = rr[num-1];
            return siteURL;
        }

    }
}
