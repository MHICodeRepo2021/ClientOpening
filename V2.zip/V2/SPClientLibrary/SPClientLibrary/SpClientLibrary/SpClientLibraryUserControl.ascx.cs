﻿using Microsoft.SharePoint;
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace SPClientLibrary.SpClientLibrary
{
    public partial class SpClientLibraryUserControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }


        protected void Client_ServerClick(object sender, EventArgs e)
        {
            SPSite site = SPContext.Current.Site;

            if (clientName.Value == "")
            {
                lblMessage.Text = "Please enter client Name";
                return;
            }
            string url = (this.Parent as SpClientLibrary).ConfidentialSiteUrl;

            if (chkConId.Checked && string.IsNullOrEmpty(url))
            {
                lblMessage.Text = "Please provide the Confidential Site Url";
                return;
            }

            string strClientName = clientName.Value.Trim().ToString().Replace("&", "and"); 
                            

            string upper = this.clientName.Value.Remove(1).ToUpper();
            int number=0;
            bool isNumeric = int.TryParse(upper, out number);
            string strWeb = string.Empty;

            if (chkConId.Checked)
            {
                strWeb = url;
            }
            else
            {
                if (!isNumeric)
                    strWeb = upper != "M" ? site.RootWeb.Url + "/" + upper  : site.RootWeb.Url + "/Mm";
                else
                    strWeb = site.RootWeb.Url + "/Numericals"; 
            }
            
           



                Guid guid = Guid.Empty;

            foreach (SPWeb web in site.AllWebs)
            {

                if (chkConId.Checked && web.Url.ToLower() == url.ToLower())
                {
                    guid = web.ID;
                }
                else if(isNumeric && web.Url.ToLower() == strWeb.ToLower())
                {
                    guid = web.ID;
                }
                else if (


                    GetSiteLetter(  web.Url.ToLower())==  strClientName.Substring(0, 1)
                    || web.Url.ToLower() == strWeb.ToLower())
                {
                    guid = web.ID;
                    break;
                }

            }

                if (guid ==Guid.Empty )
                {
                    lblMessage.Text = "Destination site "+ strClientName.Substring(0, 1).ToUpper() + "{"+strWeb+ "} is not exist ";
                    return;
                }

             //string str4 = "Stratus Code:" + this.stratusCode.Value ;


            using (SPWeb oSPWeb = site.OpenWeb(guid))
            {

                oSPWeb.AllowUnsafeUpdates = true;

                /*create list from custom ListTemplate present within ListTemplateGalery */
                //oSPWeb.Lists.Add(strClientName, stratusCode.Value, SPListTemplateType.DocumentLibrary);
                try
                {
                    SPListTemplate customListTemplate = site.GetCustomListTemplates(oSPWeb)["Client Directory"];
                    SPListCollection lists = oSPWeb.Lists;
                    Guid guid1 = lists.Add(strClientName, "", customListTemplate);
                    oSPWeb.Update();
                    oSPWeb.AllowUnsafeUpdates = false;
                    lblMessage.Text = "Client Folder Created Successfully";
                    clientName.Value = "";
                    //stratusCode.Value = "";
                    chkConId.Checked = false;
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Error: >>" + ex.Message + " " + ex.StackTrace;
                }



            }
            
        }

        private string GetSiteLetter(string siteURL)
        {
            string[] rr = siteURL.Split('/');

            int num = rr.Length;
            siteURL = rr[num - 1];
            return siteURL;
        }

    }
}
